/** Automatically generated file. DO NOT MODIFY */
package com.push.final_try_to_implement_push;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}