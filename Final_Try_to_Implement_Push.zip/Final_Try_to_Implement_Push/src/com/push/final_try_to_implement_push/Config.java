package com.push.final_try_to_implement_push;

public interface Config {
	
	static final String APP_SERVER_URL = "http://192.168.5.88:8080/GCM-App-Server/GCMNotification?shareRegId=1";
	static final String GOOGLE_PROJECT_ID = "706035842421";
	static final String MESSAGE_KEY = "message";

}
