package com.push.final_try_to_implement_push;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity
{
	ShareExternalServer appUtil;
	String regId;
	AsyncTask shareRegidTask;
	static final String TAG = "Main Activity";

	public void OnCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Log.d(TAG, "Entered main activity");
		setContentView(R.layout.activity_main);
		Intent intent = getIntent();
		String message = intent.getStringExtra(RegisterActivity.REG_ID);
		TextView tv = (TextView) findViewById(R.id.content);
	    tv.setText("Registration id is : " + message);
		appUtil = new ShareExternalServer();

		regId = getIntent().getStringExtra("regId");
		Log.d("MainActivity", "regId: " + regId);

		final Context context = this;
		shareRegidTask = new AsyncTask() {
			
			@Override
			protected Object doInBackground(Object... params) {
				Log.i(TAG, "Sharing reg id with server");
				String result = appUtil.shareRegIdWithAppServer(context, regId);
				return result;
			}
			protected void onPostExecute(String result) {
				shareRegidTask = null;
				Toast.makeText(getApplicationContext(), result,
						Toast.LENGTH_LONG).show();
			}

		};
		shareRegidTask.execute(null, null, null);
	}
}