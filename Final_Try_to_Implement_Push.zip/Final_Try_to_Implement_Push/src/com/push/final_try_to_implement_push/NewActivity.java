package com.push.final_try_to_implement_push;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;


public class NewActivity extends Activity  {

	static final String TAG = "New Activity";
	ShareExternalServer appUtil;
	String regId;
	AsyncTask shareRegidTask;
	 @Override
	    protected void onCreate(Bundle savedInstanceState) {

		   super.onCreate(savedInstanceState);
		   
		   Log.d(TAG, "Entered new activity");
		   setContentView(R.layout.activity_new);
		   Intent intent = getIntent();
			String message = intent.getStringExtra(RegisterActivity.REG_ID);
			TextView tv = (TextView) findViewById(R.id.content);
		    tv.setText("Registration id is : " + message);
			appUtil = new ShareExternalServer();

			regId = getIntent().getStringExtra("regId");
			Log.d("MainActivity", "regId: " + regId);

			final Context context = this;
			shareRegidTask = new AsyncTask() {
				
				@Override
				protected Object doInBackground(Object... params) {
					Log.i(TAG, "Sharing reg id with server");
					String result = appUtil.shareRegIdWithAppServer(context, regId);
					return result;
				}
				protected void onPostExecute(String result) {
					shareRegidTask = null;
					Toast.makeText(getApplicationContext(), result,
							Toast.LENGTH_LONG).show();
				}

			};
			shareRegidTask.execute(null, null, null);
		   
			   
	    }

	    @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	        // Handle app bar item clicks here. The app bar
	        // automatically handles clicks on the Home/Up button, so long
	        // as you specify a parent activity in AndroidManifest.xml.
	        int id = item.getItemId();
	        if (id == R.id.action_settings) {
	            return true;
	        }
	        return super.onOptionsItemSelected(item);
	    }

	    /**
	     * A placeholder fragment containing a simple view.
	     */
	    public static class PlaceholderFragment extends Fragment {

	        public PlaceholderFragment() { }

	        @Override
	        public View onCreateView(LayoutInflater inflater, ViewGroup container,
	                  Bundle savedInstanceState) {
	              View rootView = inflater.inflate(R.layout.activity_new,
	                      container, false);
	              return rootView;
	        }
	    }
}
