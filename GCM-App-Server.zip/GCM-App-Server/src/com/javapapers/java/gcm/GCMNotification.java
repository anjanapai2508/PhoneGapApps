package com.javapapers.java.gcm;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;

@WebServlet("/GCMNotification")
public class GCMNotification extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// Put your Google API Server Key here
	private static final String GOOGLE_SERVER_KEY = "AIzaSyBHswJzf347H9Pbw17uyTzKHLpoxrtqRtM";
	static final String MESSAGE_KEY = "message";	

	public GCMNotification() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {


		Result result = null;

		String share = request.getParameter("shareRegId");
		//System.out.println("share : " +share);
         //String share = "";
		// GCM RedgId of Android device to send push notification
		String regId = "";
		if (share != null && !share.isEmpty()) {
			regId = request.getParameter("regId");
			//System.out.println("Reg id : " +regId);
			//regId = "ceBes0rM_wY:APA91bFlbtCM2fYlgo6ykisshy14WgtNMuM-E06o9ZYl12PARCtYVC4M0wy2U4O66CimmwQ675SUhIsM2JgMgRl2-JaOXBf-1GZhwbhs6VOSolVBwQzloQk43VzwU-NyCdd9Aw2njlg_";
			PrintWriter writer = new PrintWriter("GCMRegId.txt");
			writer.println(regId);
			writer.close();
			request.setAttribute("pushStatus", "GCM RegId Received.");
			request.getRequestDispatcher("index.jsp")
					.forward(request, response);
		} else {
			//System.out.println("oops i got into else");
			try {
				BufferedReader br = new BufferedReader(new FileReader(
						"GCMRegId.txt"));
				regId = br.readLine();
				br.close();
				String userMessage = request.getParameter("message");
				Sender sender = new Sender(GOOGLE_SERVER_KEY);
				Message message = new Message.Builder().timeToLive(30)
						.delayWhileIdle(true).addData(MESSAGE_KEY, userMessage).build();
				//System.out.println("regId: " + regId);
				result = sender.send(message, "adasdasdasdasdsa", 1);
				request.setAttribute("pushStatus", result.toString());
				System.out.println("ErrorCodeName obtained from GCM server : " +result.getErrorCodeName());
				System.out.println("CanonicalRegistrationId obtained from GCM server : " +result.getCanonicalRegistrationId());
				System.out.println("MessageId obtained from GCM server : " +result.getMessageId());
				System.out.println("Result string obtained from GCM server : " +result.toString());
			} catch (IOException ioe) {
				ioe.printStackTrace();
				request.setAttribute("pushStatus",
						"RegId required: " + ioe.toString());
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("pushStatus", e.toString());
				System.out.println("Push status returned in exception e: " +e.toString());
			}
			request.getRequestDispatcher("index.jsp")
					.forward(request, response);
		}
	}
}
